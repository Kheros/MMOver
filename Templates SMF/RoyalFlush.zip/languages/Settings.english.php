<?php
// Version: 2.0 RC3; Settings

// Important! Before editing these language files please read the text at the top of index.english.php.

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = '<a href="http://www.skinmod.eu" target="_blank">Royal Flush</a> Adapted - by c#~Pl0P.-xD.';

?>