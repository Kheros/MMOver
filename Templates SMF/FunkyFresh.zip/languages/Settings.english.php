<?php
// Version: 2.0 RC4; Settings

// Important! Before editing these language files please read the text at the top of index.english.php.

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = '<a href="http://www.skinmod.eu" target="_blank">Funky Fresh</a> Adapted - by zutzu.';

?>