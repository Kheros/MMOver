<?php
// Version: 2.0 RC4; Themes
global $context, $scripturl;

$txt['welcome'] = 'Bienvenido a '.$context['forum_name'].'.';
$txt['newpost'] = 'Nuevos temas';
$txt['newreplies'] = 'Nuevas respuestas';
$txt['publicity'] = 'Codigo publicitario';
$txt['publicity_desc'] = 'Aqui puede colocar su codigo publicitario, texto, etc. (BBC Habilitado)';
$txt['enable_publi'] = 'Activar Publicidad en la Cabecera';
$txt['disable_publi'] = 'Desactivado';
$txt['guest_publi'] = 'Visible solo a visitantes';
$txt['user_publi'] = 'Visible solo a usuarios';
$txt['all_publi'] = 'Visible a todos';
$txt['enable_footer_links'] = 'Activar enlaces del Pie de la pagina';
$txt['reply_quote'] = 'Responder citando';
$txt['width_forum'] = 'Ancho de todo el foro';
$txt['width_boards'] = 'Ancho de foros y centro de estadisticas';
$txt['change_color'] = 'Variacion de color';
$txt['red_color'] = 'Color rojo';
$txt['blue_color'] = 'Color azul';
$txt['green_color'] = 'Color verde';
$txt['type_publi'] = 'Tipo de codigo';
$txt['bbc_publi'] = 'BBC';
$txt['html_publi'] = 'HTML';
?>