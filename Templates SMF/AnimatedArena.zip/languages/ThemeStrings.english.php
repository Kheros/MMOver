<?php
// Version: 2.0 RC4; Themes
global $context, $scripturl;

$txt['welcome'] = 'Welcome to '.$context['forum_name'].'';
$txt['newpost'] = 'News posts';
$txt['newreplies'] = 'News replies';
$txt['publicity'] = 'Publicity code';
$txt['publicity_desc'] = 'Here you can place your code publicity, text, etc. (BBC Enable)';
$txt['enable_publi'] = 'Enable publicity block in header';
$txt['disable_publi'] = 'Disable';
$txt['guest_publi'] = 'Show only for guest';
$txt['user_publi'] = 'Show only for members';
$txt['all_publi'] = 'Show to all';
$txt['enable_footer_links'] = 'Enable links in footer';
$txt['reply_quote'] = 'Reply with quote';
$txt['width_forum'] = 'width forum';
$txt['width_boards'] = 'specify the width of boards and info center';
$txt['change_color'] = 'Color Variation';
$txt['red_color'] = 'Red color';
$txt['blue_color'] = 'Blue color';
$txt['green_color'] = 'Green color';
$txt['type_publi'] = 'Code type';
$txt['bbc_publi'] = 'BBC';
$txt['html_publi'] = 'HTML';
?>