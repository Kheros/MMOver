<?
/*****************************************************************
* install.php  Version 1.0.3                                     *
* Special Advanced Version for Easier Handling                   *
* Programmed / Copyright By DIN1031 (http://www.ayu-kult.de/)    *
* for SMF (http://www.simplemachines.org)                        *
*****************************************************************/
/*****************************************************************
* It's free to change and use everywhere who this file is        *
* useable and made his work. You can change the code as you like *
* it. The only thing that i wish is, add the first 7 Lines of    *
* this file                                                      * 
* THANKS A LOT                                                   *
*****************************************************************/
/*****************************************************************
* Used for follow Software                                       *
* Programm:      MemberColorLink                                 *
* By:            DIN1031 (http://www.ayu-kult.de/)               *
* Copyright:     DIN1031 (http://www.ayu-kult.de/)               *
*****************************************************************/

global $db_prefix, $modSettings, $smcFunc;

//This is a way to install the mod without the package parser!
$SSI_INSTALL = false;
if(!isset($db_prefix)) {
	require('SSI.php');
	$SSI_INSTALL = true;
}

// I want to be sure that this is loaded
if(empty($smcFunc['db_change_column']))
	db_extend('packages');

// Change this in a compatible way ;)
$changed_field = array(
	'name' => 'online_color',
	'type' => 'varchar',
	'size' => '255',
	'null' => false
);
$smcFunc['db_change_column'] ('membergroups', 'online_color', $changed_field);

//Give a proper answer on ssi install ;)
if($SSI_INSTALL)
	echo 'DB Changes should be made now...';
?>