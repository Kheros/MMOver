Install the Modifcation [url=http://custom.simplemachines.org/mods/index.php?mod=111]Member Color Link[/url]

This Mod change the link of the Members so that the color of the Group is the link color.
You can switch on the option in the forum settings. 

[img]http://www.din1031.de/bilder/boardspic/LinkColorMod.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorMod2.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorModv130-1.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorModv130-2.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorModv140.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorMod170-1.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorMod170-2.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorMod170-3.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorMod170-4.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorMod170-5.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorModv180-1.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorModv180-2.jpg[/img][img]http://www.din1031.de/bilder/boardspic/LinkColorModv180-3.jpg[/img]

Follow Languages are included:
English (utf8), Italiano (utf8) (Italian), and Deutsch (utf8) (German)

Follow Outdated Languages are included:
Espa�ol (Spanish), T�rk�e (utf8) (Turkish), Nederlands (utf8) (Dutch), Portugu�s (utf8) (Portuguese), Brazilian, Svenska (Swedish) (utf8)

[url=http://www.din1031.de/donation/]If you like to donate me some Money. [color=red]Click Here[/color][/url]
